package com.Bianyi;

import java.io.*;

public class Main {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		Show sh=new Show();
		sh.showMain();
	}
}